# Deploy-Application-on-Cloud
 This repository contains the Spring Boot Application code with the Dockerfile. 
 
 The **Screenshots** of **Deployment on cloud** and **Writeup** are attached as PDFs.
