/**
 * Questo package si occupa di gestire alcune classi necessarie per il corretto funzionamento delle applicazioni per
 * la connessione al database
 *
 * @author Alex Vellone, Manuel Macaj
 * @since 1.0
 */
package global;