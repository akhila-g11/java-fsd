/**
 * Questo package si occupa di gestire l'interfaccia grafica dell'applicazione centri vaccinali
 *
 * @author Mahdi Said
 * @since 1.0
 */
package centrivaccinali;