/**
 * Questo package si occupa di gestire il server e la connessione al databse postgresql
 *
 * @author Alex Vellone, Manuel Macaj
 * @since 1.0
 */
package serverCV;