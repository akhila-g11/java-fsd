/**
 * In questo package sono definiti tutti i modelli delle tabelle presenti nel database
 *
 * @author Silvio Pazienza
 * @since 1.0
 */
package models;