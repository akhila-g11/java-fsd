/**
 * Questo package si occupa di gestire l'interfaccia grafica dell'applicazione cittadini
 *
 * @author Manuel Macaj, Silvio Pazienza, Alex Vellone, Mahdi Said
 * @since 1.0
 */
package cittadini;